from distutils.core import setup

setup(
    name='tkinterGui',
    version='',
    packages=[''],
    package_dir={'': 'src'},
    url='',
    license='',
    author='owner',
    author_email='',
    description=''
)
